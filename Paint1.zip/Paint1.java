import java.util.Scanner;

public class Paint1 {

    public static void main(String[] args) {
        Scanner scnr = new Scanner(System.in);
        double wallHeight = 0.0;
        double wallWidth = 0.0;
        double wallArea = 0.0;
        double gallonsPaintNeeded = 0.0;
        
        final double squareFeetPerGallons = 350.0;
        boolean validInput;

        // Added do-while loop and exception handling for wall height input
        do {
            validInput = true;
            System.out.print("Enter wall height (feet): ");
            try {
                wallHeight = Double.parseDouble(scnr.nextLine()); // Changed to parse from string for validation
                if (wallHeight <= 0) {
                    System.out.println("Height must be a positive number."); // Added validation for positive input
                    validInput = false;
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a numeric value."); // Added exception handling
                validInput = false;
            }
        } while (!validInput);

        // Added do-while loop and exception handling for wall width input
        do {
            validInput = true;
            System.out.print("Enter wall width (feet): ");
            try {
                wallWidth = Double.parseDouble(scnr.nextLine()); // Fixed bug: previously reassigned wallHeight
                if (wallWidth <= 0) {
                    System.out.println("Width must be a positive number."); // Added validation for positive input
                    validInput = false;
                }
            } catch (NumberFormatException e) {
            	System.out.println("Invalid input. Please enter a numeric value."); // Added exception handling
                validInput = false;
            }
        } while (!validInput);

        wallArea = wallHeight * wallWidth; // Fixed logic: now uses correct height and width
        System.out.println("Wall area: " + wallArea + " square feet"); // Fixed output: now displays actual area

        gallonsPaintNeeded = wallArea / squareFeetPerGallons; // Fixed logic: uses correct constant
        System.out.println("Paint needed: " + gallonsPaintNeeded + " gallons"); // Fixed typo in variable name
    }
}
